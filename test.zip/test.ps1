New-Item c:\temp\output.txt
Set-Content c:\temp\output.txt ' Hi, the content is replaced successfully'